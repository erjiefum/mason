const officegen = require('officegen');
const mammoth = require('mammoth');
const fs = require('fs')
const docx = officegen('docx');

let getNextWord = (content) => {

}
const writer = fs.createWriteStream("../chat_record/武林外传.txt"+'.txt', {
    flags: 'a', //如果要把内容追加到文件原有的内容的后面，则设置flags为'a',此时设置start无效
})
const writer2 = fs.createWriteStream("../chat_record/武林外传8"+'.txt', {
    flags: 'a', //如果要把内容追加到文件原有的内容的后面，则设置flags为'a',此时设置start无效
})
fs.readFile("../chat_record/武林外传7.txt", 'utf-8',(err, data) => {
    // console.log("data.length---------------", data[0], data[data.length-1])
    data = "{\"value\":" + data + "}"
    let arr = JSON.parse(data).value;
    // console.log(typeof arr);
    writer2.write("[")
    arr.forEach((item) => {
        let name = item.name;
        let content = item.content;
        let _flagName = name.indexOf("（");
        let flagName_ = name.indexOf("）");
        let _flagContent = content.indexOf("（");
        let flagContent_ = content.indexOf("）");
        if(_flagName!=-1&&flagName_!=-1){
            let name1 = name.substring(0, _flagName);
            let name2 = name.substring(flagName_+1);
            name = name1 + name2;
        }
        if(_flagContent!=-1&&flagContent_!=-1){
            let content1 = content.substring(0, _flagContent);
            let content2 = content.substring(flagContent_+1);
            content = content1 + content2;
        }
        if(name.length < 6){
            writer2.write(`{
                "name": "${name}",
                "content": "${content}"
            },`)
        }
        
    })
    writer2.write(']')
    console.log(arr[0]);
})

let docxPath = "../chat_record/《武林外传》全剧本-已解锁.docx";
// mammoth.extractRawText({path: docxPath}).then(res => {
//     console.log("-----------------------res------------------------");
//     let str = res.value;
//     startFlag = str.indexOf('（老邢从大门出来，掌柜跟出） 邢育森：我得走~');
//     str = str.substring(startFlag+25);
//     let i = 0;
//     writer.write("[")
//     while(str.indexOf("\n") != -1){
//         let nFlag = str.indexOf("\n");
//         let thisLine = str.substring(0, nFlag);
//         str = str.substring(nFlag + 1);
//         console.log(i++);

//         if(thisLine.indexOf("：")!=-1){
//             let flag = thisLine.indexOf("：");
//             writer.write(`{
//                 "name": "${thisLine.substring(0, flag+1)}",
//                 "content": "${thisLine.substring(flag+1)}"
//             },`)
//         }
//     }
//     writer.write("]")
//     console.log("write end!")
    
// }).catch(err => {
//     console.log("-----------------err---------------------------");
//     console.log(err);
// }).done()