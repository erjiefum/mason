let keywords = [
    "不知道吃啥",
    "中午吃啥呢",
    "晚上吃啥呢",
    "吃点啥呢",
    "不知道吃什么",
    "中午吃什么",
    "晚上吃什么"
]

let getFood = (callback) => {
    
}